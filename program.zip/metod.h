/*
Namn: Robar Zangana
Datum: 11/12/18
Kurs: Introduktion till programmering i C++
Labboration: Laboration fem
*/
#ifndef METOD_H
#define METOD_H

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <iterator>
#include <algorithm>
using namespace std;

string cout_word(string document);

#endif